<?php

declare(strict_types=1);

namespace Doctrine\DBAL\SQL\Parser;

use Throwable;

interface Exception extends Throwable
{
}
