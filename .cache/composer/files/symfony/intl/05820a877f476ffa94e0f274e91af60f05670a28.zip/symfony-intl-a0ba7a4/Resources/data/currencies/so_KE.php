<?php

return [
    'Names' => [
        'KES' => [
            'Ksh',
            'Shilingka Kenya',
        ],
    ],
];
