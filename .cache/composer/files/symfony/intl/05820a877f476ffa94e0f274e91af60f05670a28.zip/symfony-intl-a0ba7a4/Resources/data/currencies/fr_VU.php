<?php

return [
    'Names' => [
        'VUV' => [
            'VT',
            'vatu vanuatuan',
        ],
    ],
];
