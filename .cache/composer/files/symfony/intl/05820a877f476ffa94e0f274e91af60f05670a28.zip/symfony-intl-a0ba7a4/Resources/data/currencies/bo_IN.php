<?php

return [
    'Names' => [
        'CNY' => [
            'CN¥',
            'ཡུ་ཨན་',
        ],
    ],
];
