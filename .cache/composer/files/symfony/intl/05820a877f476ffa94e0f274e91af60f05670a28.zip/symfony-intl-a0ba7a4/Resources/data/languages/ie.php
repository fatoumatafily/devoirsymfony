<?php

return [
    'Names' => [
        'en' => 'anglesi',
        'ie' => 'Interlingue',
    ],
    'LocalizedNames' => [],
];
