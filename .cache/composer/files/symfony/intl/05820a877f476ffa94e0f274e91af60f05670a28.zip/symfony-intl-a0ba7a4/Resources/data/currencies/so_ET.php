<?php

return [
    'Names' => [
        'ETB' => [
            'Br',
            'Birta Itoobbiya',
        ],
    ],
];
