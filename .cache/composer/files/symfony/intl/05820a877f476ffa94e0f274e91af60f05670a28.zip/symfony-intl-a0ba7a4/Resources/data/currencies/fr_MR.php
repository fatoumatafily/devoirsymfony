<?php

return [
    'Names' => [
        'MRU' => [
            'UM',
            'ouguiya mauritanien',
        ],
    ],
];
