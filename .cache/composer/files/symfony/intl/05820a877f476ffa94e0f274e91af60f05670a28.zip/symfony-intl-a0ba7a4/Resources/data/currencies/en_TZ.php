<?php

return [
    'Names' => [
        'TZS' => [
            'TSh',
            'Tanzanian Shilling',
        ],
    ],
];
