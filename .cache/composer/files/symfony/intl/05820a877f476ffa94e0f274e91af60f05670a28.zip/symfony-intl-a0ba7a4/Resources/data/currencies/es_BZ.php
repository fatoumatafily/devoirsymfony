<?php

return [
    'Names' => [
        'BZD' => [
            '$',
            'dólar beliceño',
        ],
    ],
];
