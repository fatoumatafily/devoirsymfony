<?php

return [
    'Names' => [
        'LRD' => [
            '$',
            'Liberian Dollar',
        ],
    ],
];
