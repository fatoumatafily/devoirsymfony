<?php

return [
    'Names' => [
        'CUP' => [
            '$',
            'peso cubano',
        ],
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
    ],
];
