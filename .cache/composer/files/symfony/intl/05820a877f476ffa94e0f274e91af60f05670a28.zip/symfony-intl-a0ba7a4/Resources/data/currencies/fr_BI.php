<?php

return [
    'Names' => [
        'BIF' => [
            'FBu',
            'franc burundais',
        ],
    ],
];
