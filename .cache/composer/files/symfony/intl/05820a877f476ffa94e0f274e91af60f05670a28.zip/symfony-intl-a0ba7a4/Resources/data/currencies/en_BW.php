<?php

return [
    'Names' => [
        'BWP' => [
            'P',
            'Botswanan Pula',
        ],
    ],
];
