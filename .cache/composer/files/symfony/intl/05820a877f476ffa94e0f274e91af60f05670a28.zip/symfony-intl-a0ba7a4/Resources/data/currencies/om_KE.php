<?php

return [
    'Names' => [
        'KES' => [
            'Ksh',
            'KES',
        ],
    ],
];
