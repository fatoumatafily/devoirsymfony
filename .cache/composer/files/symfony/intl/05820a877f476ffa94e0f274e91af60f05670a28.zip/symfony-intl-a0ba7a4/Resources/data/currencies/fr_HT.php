<?php

return [
    'Names' => [
        'HTG' => [
            'G',
            'gourde haïtienne',
        ],
    ],
];
