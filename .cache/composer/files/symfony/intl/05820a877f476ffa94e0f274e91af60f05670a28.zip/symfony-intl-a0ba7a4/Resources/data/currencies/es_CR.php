<?php

return [
    'Names' => [
        'CRC' => [
            '₡',
            'colón costarricense',
        ],
    ],
];
