<?php

return [
    'Names' => [
        'JMD' => [
            '$',
            'Jamaican Dollar',
        ],
    ],
];
