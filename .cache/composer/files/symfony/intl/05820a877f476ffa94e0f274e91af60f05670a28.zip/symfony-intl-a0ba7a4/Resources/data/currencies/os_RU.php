<?php

return [
    'Names' => [
        'GEL' => [
            'GEL',
            'Лар',
        ],
        'RUB' => [
            '₽',
            'Сом',
        ],
    ],
];
