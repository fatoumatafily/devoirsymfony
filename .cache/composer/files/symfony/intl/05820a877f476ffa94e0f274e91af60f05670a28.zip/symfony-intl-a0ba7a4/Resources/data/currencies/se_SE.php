<?php

return [
    'Names' => [
        'NOK' => [
            'Nkr',
            'norgga kruvdno',
        ],
        'SEK' => [
            'kr',
            'ruoŧŧa kruvdno',
        ],
    ],
];
