CHANGELOG
=========

7.1
---

 * Add the component as experimental
